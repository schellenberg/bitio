This is just a package containing David Whaley's 
bitio module, so that it can be easily installed in Thonny using
Manage Packages (pip install). This simplifies the install process
for the students, so they don't need to worry about where to save files.

